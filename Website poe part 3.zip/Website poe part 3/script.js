

(function highlightActiveNav() {
    const currentPage = window.location.pathname.split('/').pop() || 'index.html';
    document.querySelectorAll('nav a').forEach(link => {
        const href = link.getAttribute('href');
        if (href === currentPage) {
            link.classList.add('active');
        }
    });
})();



function showToast(message, duration = 3500) {
    const toast = document.getElementById('toast');
    if (!toast) return;
    toast.textContent = message;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), duration);
}



const bookingForm = document.getElementById('booking-form');
if (bookingForm) {
    bookingForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const fullname = document.getElementById('fullname').value.trim();
        const email = document.getElementById('email').value.trim();
        const sessionType = document.getElementById('sessionType').value;
        const date = document.getElementById('date').value;
        const time = document.getElementById('time').value;
        const modeSelected = document.querySelector('input[name="mode"]:checked');

        
        if (!fullname || !email || !sessionType || !date || !time || !modeSelected) {
            showToast('⚠️ Please fill in all required fields before submitting.');
            return;
        }


        const selectedDate = new Date(date);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        if (selectedDate < today) {
            showToast('⚠️ Please select a future date for your session.');
            return;
        }

    
        showToast(`✅ Session booked! We will confirm via email, ${fullname.split(' ')[0]}.`);
        bookingForm.reset();

    
        bookingForm.scrollIntoView({ behavior: 'smooth', block: 'start' });
    });
}



const contactBtn = document.getElementById('contact-submit-btn');
if (contactBtn) {
    contactBtn.addEventListener('click', function () {
        const name = document.getElementById('contact-name')?.value.trim();
        const email = document.getElementById('contact-email')?.value.trim();
        const message = document.getElementById('contact-message')?.value.trim();

        if (!name || !email || !message) {
            showToast('⚠️ Please fill in your name, email, and message.');
            return;
        }

        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            showToast('⚠️ Please enter a valid email address.');
            return;
        }

        showToast(`💚 Thank you, ${name.split(' ')[0]}! We'll get back to you soon.`);

        
        document.getElementById('contact-name').value = '';
        document.getElementById('contact-email').value = '';
        document.getElementById('contact-message').value = '';
        const reasonSelect = document.getElementById('contact-reason');
        if (reasonSelect) reasonSelect.selectedIndex = 0;
    });
}



function animateCounter(element, target, duration = 2000) {
    let start = 0;
    const step = target / (duration / 16);
    const timer = setInterval(() => {
        start += step;
        if (start >= target) {
            element.textContent = target.toLocaleString() + (target >= 100 ? '+' : '');
            clearInterval(timer);
        } else {
            element.textContent = Math.floor(start).toLocaleString();
        }
    }, 16);
}

const statTargets = {
    counter1: 1200,
    counter2: 3400,
    counter3: 18,
    counter4: 7
};


const statsSection = document.querySelector('.stats-row');
if (statsSection) {
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                Object.entries(statTargets).forEach(([id, target]) => {
                    const el = document.getElementById(id);
                    if (el) animateCounter(el, target);
                });
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.4 });
    observer.observe(statsSection);
}



document.querySelectorAll('.faq-question').forEach(btn => {
    btn.addEventListener('click', function () {
        const item = this.closest('.faq-item');
        const isOpen = item.classList.contains('open');

        
        document.querySelectorAll('.faq-item').forEach(i => i.classList.remove('open'));

        
        if (!isOpen) {
            item.classList.add('open');
        }
    });
});



(function setupScrollReveal() {
    const cards = document.querySelectorAll('.card, .testimonial-card, .contact-info, .highlight-box');
    if (!cards.length) return;

    cards.forEach(card => {
        card.style.opacity = '0';
        card.style.transform = 'translateY(24px)';
        card.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
    });

    const revealObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry, index) => {
            if (entry.isIntersecting) {
                setTimeout(() => {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }, index * 80);
                revealObserver.unobserve(entry.target);
            }
        });
    }, { threshold: 0.15 });

    cards.forEach(card => revealObserver.observe(card));
})();



(function setPageGreeting() {
    const hour = new Date().getHours();
    let greeting = '';
    if (hour < 12) greeting = 'Good morning';
    else if (hour < 17) greeting = 'Good afternoon';
    else greeting = 'Good evening';

    const heroBanner = document.querySelector('.hero-banner p');
    if (heroBanner && window.location.pathname.includes('index')) {
        heroBanner.textContent = greeting + '. ' + heroBanner.textContent;
    }
})();
